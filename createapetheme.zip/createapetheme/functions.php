<?php 
//Add theme supports
function init_template(){
    add_theme_support( 'post-thumbnails');
    add_theme_support( 'title-tag' );

    register_nav_menus(
        array(
        'top_menu' => 'Principal'
        )
    );
}

add_action('after_setup_theme','init_template');

function template_styles(){
    wp_register_style('bootstrap','https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css',false,'5.2.0','all');
    wp_register_style('montserrat','https://fonts.googleapis.com/css?family=Montserrat&display=swap',false,'','all');
    wp_register_style( 'style', get_stylesheet_directory_uri().'/assets/styles/css/main.css' );
    wp_enqueue_style('main-style', get_stylesheet_uri(), array('bootstrap','montserrat', 'style'),'1.0','all');
    
    wp_enqueue_script( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js', array('jquery','popper'), true);

    wp_enqueue_script( 'custom', get_template_directory_uri()."/assets/js/custom.js", false,"1.1", true );
}

add_action('wp_enqueue_scripts','template_styles');


function register_acf_block_types() {
        // register a hero block.
		acf_register_block_type(array(
        'name'				=> 'hero',
        'title'				=> __( 'Hero'),
        'description'		=> __( 'A custom hero block.'),
        'render_template'   => 'template-parts/blocks/hero.php',
        'category'			=> 'common',
        'icon'				=> 'align-center',
        'keywords'			=> array( 'hero', 'banner' ),
                
        ));

        // register a benefits section block.
		acf_register_block_type(array(
            'name'				=> 'benefits',
            'title'				=> __( 'benefits'),
            'description'		=> __( 'A custom benefits section block.'),
            'render_template'   => 'template-parts/blocks/benefits.php',
            'category'			=> 'design',
            'icon'				=> 'yes',
            'keywords'			=> array( 'benefits', 'section' ),
                    
            ));
}

 // Check if function exists and hook into setup.
if( function_exists('acf_register_block_type') ) {
    add_action('acf/init', 'register_acf_block_types');}

//Menu options ACF
if( function_exists('acf_add_options_page') ) {
	
	acf_add_options_page(array(
		'page_title' 	=> 'Theme General Settings',
		'menu_title'	=> 'Theme Settings',
		'menu_slug' 	=> 'theme-general-settings',
		'capability'	=> 'edit_posts',
		'redirect'		=> false
	));
	
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Theme Header Settings',
		'menu_title'	=> 'Header',
		'parent_slug'	=> 'theme-general-settings',
	));
		
}

// SVG Implent
function custom_mimes( $mimes = array() ) {
	// New allowed mime types.
    $mimes['svg'] = 'image/svg+xml';
    $mimes['svgz'] = 'image/svg+xml';
    return $mimes;
}
add_filter( 'upload_mimes', 'custom_mimes' );

// FontAwesome Integration
add_action( 'wp_enqueue_scripts', 'enqueue_load_fa' );
function enqueue_load_fa() {
wp_enqueue_style( 'load-fa', 'https://pro.fontawesome.com/releases/v5.10.0/css/all.css' );
}

