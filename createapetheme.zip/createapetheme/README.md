# Create Ape
## _Wordpress theme by Create Ape

![N|Solid](https://lubg5w0f28-flywheel.netdna-ssl.com/wp-content/uploads/2021/07/new_logo.svg)

This theme was developed with the highest quality standards, thinking about each of our client's needs.

## Features

- Responsive design
- Easy to maintain and configure
- Fast

## Tech

Dillinger uses a number of open source projects to work properly:

- Bootstrap - CSS framework!
- ACF - Content editor
- Sass -CSS with superpowers.


## Development

I can do much more than this for Create Ape, the sky is the limit.
