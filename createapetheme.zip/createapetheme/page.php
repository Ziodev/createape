<!-- in this file the view of the page is generated, you can consult the following source
for more info: https://developer.wordpress.org/themes/basics/template-hierarchy/ -->

<?php get_header();?>
<!-- container and loop for the view -->
<main class="container my-5">
    <h1 class='my-3'><?php the_title();?></h1>
    <?php if(have_posts()){
         while(have_posts()){ the_post();
            the_content();
        }
    }?>
</main>
<?php get_footer();?>