<div class="row my-5">
    <div class="col-6">
        <?php previous_post_link(); ?>
    </div>
    <div class="col-6 text-right">
        <?php next_post_link(); ?>
    </div>
</div>