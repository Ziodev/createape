<?php
/**
 * Block template file: template-parts/blocks/benefits.php
 *
 * Benefits Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'benefits-' . $block['id'];
if ( ! empty($block['anchor'] ) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-benefits col-12';
if ( ! empty( $block['className'] ) ) {
    $classes .= ' ' . $block['className'];
}
if ( ! empty( $block['align'] ) ) {
    $classes .= ' align' . $block['align'];
}
?>

<style type="text/css">
	<?php echo '#' . $id; ?> {
		
	}
</style>



<div id="<?php echo esc_attr( $id ); ?>" class="container <?php echo esc_attr( $classes ); ?>">
    <div class="row benefits-wrapper">
        <div class="title_section">
        <h2 class="benefits-title"><?php the_field( 'benefits_title' ); ?></h2>
        <p class="benefits-description"><?php the_field( 'benefits_description' ); ?></p>
    </div>
</div>

    <div class="row wrapper-benefits">
    <div class="col-lg-4 benefits-col">
    <div class="benefit_element">
    <?php if ( have_rows( 'benefit 1' ) ) : ?>
		<?php while ( have_rows( 'benefit 1' ) ) : the_row(); ?>
            <div class="wrapper">
                <?php $icon_benefit = get_sub_field( 'icon_benefit' ); ?>
                    <?php if ( $icon_benefit ) : ?>
                        <img src="<?php echo esc_url( $icon_benefit['url'] ); ?>" alt="<?php echo esc_attr( $icon_benefit['alt'] ); ?>" />
                <?php endif; ?>
                <p class="benefit_title">
                    <?php the_sub_field( 'title_benefit' ); ?>
                </p>
            </div>
			<p class="benefit_description"><?php the_sub_field( 'description_benefit' ); ?> </p> 
		    <?php endwhile; ?>
	        <?php endif; ?>
    </div>
        </div>

    <div class="col-lg-4 benefits-col">
        <div class="benefit_element">
        <?php if ( have_rows( 'benefits_2' ) ) : ?>
		<?php while ( have_rows( 'benefits_2' ) ) : the_row(); ?>
        <div class="wrapper">
            <?php $icon_benefit = get_sub_field( 'icon_benefit' ); ?>
                <?php if ( $icon_benefit ) : ?>
                    <img src="<?php echo esc_url( $icon_benefit['url'] ); ?>" alt="<?php echo esc_attr( $icon_benefit['alt'] ); ?>" />
            <?php endif; ?>
            <p class="benefit_title">
                <?php the_sub_field( 'title_benefit' ); ?>
            </p>
        </div>

			<p class="benefit_description"> <?php the_sub_field( 'description_benefit' ); ?> </p>
		<?php endwhile; ?>
	<?php endif; ?>
    </div>
    </div>

    <div class="col-lg-4 benefits-col">
        <div class="benefit_element">
	    <?php if ( have_rows( 'benefits_3' ) ) : ?>
		<?php while ( have_rows( 'benefits_3' ) ) : the_row(); ?>

            <div class="wrapper">
                <?php $icon_benefit = get_sub_field( 'icon_benefit' ); ?>
                <?php if ( $icon_benefit ) : ?>
                    <img src="<?php echo esc_url( $icon_benefit['url'] ); ?>" alt="<?php echo esc_attr( $icon_benefit['alt'] ); ?>" />
                <?php endif; ?>            

                <p class="benefit_title">
                    <?php the_sub_field( 'title_benefit' ); ?>
                </p>
            </div>


			<p class="benefit_description"><?php the_sub_field( 'description_benefit' ); ?></p>
		<?php endwhile; ?>
	<?php endif; ?>
        </div>
    </div>
</div>

    <div class="row text-center mb-5">
        <div class="col-sm">
        <button type="button" class="custom-btn outline"><?php the_field( 'learn_more_' ); ?></button>
        </div>
    </div>
</div>
