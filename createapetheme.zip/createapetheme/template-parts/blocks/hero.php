<?php

/**
 * Block template file: template-parts/blocks/hero.php
 *
 * Hero Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'hero-' . $block['id'];
if (!empty($block['anchor'])) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-hero';
if (!empty($block['className'])) {
    $classes .= ' ' . $block['className'];
}
if (!empty($block['align'])) {
    $classes .= ' align' . $block['align'];
}
?>

<style type="text/css">
    <?php echo '#' . $id; ?> {}
</style>

<div id="<?php echo esc_attr($id); ?>" class="jumbotron jumbotron-fluid <?php echo esc_attr($classes); ?>">

    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 hero-info">
                <h1 class="hero_title"><?php the_field('hero_cta_title'); ?></h1>
                <p class="hero_description"><?php the_field('hero_cta_description'); ?></p>
                <?php $hero_cta = get_field('hero_cta'); ?>
                <?php if ($hero_cta) : ?>
                    <a class="custom-btn primary text-md-center" href="<?php echo esc_url($hero_cta['url']); ?>" target="<?php echo esc_attr($hero_cta['target']); ?>"><?php echo esc_html($hero_cta['title']); ?></a>
                <?php endif; ?>
            </div>

            <div class="col-lg-6 col-md-12 hero-image">
                <?php if (get_field('hero_image')) : ?>
                    <img src="<?php the_field('hero_image'); ?>" class="hero-img" />
                <?php endif ?>
            </div>
        </div>
    </div>
</div>