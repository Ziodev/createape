<?php get_header();?>

<main class="container">
    <div class="pagina404 my-5">
        <h1>404 PAGE NOT FOUND</h1>
        <h2>Haga <a href="<?php echo home_url();?>">click here</a> to go to the main page </h2>
    </div>
</main>

<?php get_footer();?>