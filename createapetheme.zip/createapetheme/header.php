<!-- Here starts the header of our theme -->
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Support for special characters and registration of our head -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php wp_head(); ?>
</head>

<body>

    <header>
        <div class="container">
            <div class="row align-items-center">
                <!-- Web Logo -->
                <div class="col-lg-2 col-md-4 col-12">
                    <div class="logo">
                        <?php if (get_field('logo', 'option')) : ?>
                            <img src="<?php the_field('logo', 'option'); ?>" />
                        <?php endif ?>
                    </div>
                </div>

                <!-- Implementation of the menu, previously registered in the functions.php file. -->
                <div class="col-lg-6 col-md-8 col-12 menu">
                    <nav>
                        <?php wp_nav_menu(array(
                            'theme_location' => 'top_menu',
                            'menu_class' => 'menu-principal',
                            'container_class' => 'container-menu',
                        )); ?>
                    </nav>
                </div>

                <div class="col-lg-4 col-md-12 col-12 header-info">
                    <!-- Implementation of the search. -->
                    <?php $search = get_field('search', 'option'); ?>
                    <?php if ($search) : ?>
                        <img src="<?php echo esc_url($search['url']); ?>" alt="<?php echo esc_attr($search['alt']); ?>" />
                    <?php endif; ?>
                    <!-- phone number - right area header -->
                    <p><?php the_field('phone_number', 'option'); ?></p>
                    
                    <!-- call to action button, right zone header -->
                    <button type="button" class="custom-btn primary"><?php the_field('lets_talk_top', 'option'); ?></button>
                </div>
            </div>
        </div>
    </header>